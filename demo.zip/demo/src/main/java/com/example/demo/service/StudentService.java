package com.example.demo.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

	private List<Student> students = new ArrayList<>();
	private int idCounter = 1;

	// Get all students
	public List<Student> getAllStudents() {
		return students;
	}

	// Add a student
	public Student addStudent(Student student) {
		student.setId(idCounter++);
		students.add(student);
		return student;
	}

	// Delete a student by ID
	public void deleteStudent(int id) {
		students.removeIf(student -> student.getId() == id);
	}

	// Get a student by ID
	public Optional<Student> getStudentById(int id) {
		return students.stream().filter(student -> student.getId() == id).findFirst();
	}
}
