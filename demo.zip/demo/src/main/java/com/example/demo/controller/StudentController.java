package com.example.demo.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentService studentService;

	// Show all students in an HTML table
	@GetMapping
	public String showStudents(Model model) {
		model.addAttribute("students", studentService.getAllStudents());
		return "students"; // Thymeleaf view
	}

	// Show the form to add a new student
	@GetMapping("/new")
	public String showAddStudentForm(Model model) {
		model.addAttribute("student", new Student());
		return "new-student"; // Form view
	}

	// Save new student with validation
	@PostMapping("/save")
	public String saveStudent(@Valid @ModelAttribute Student student, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "new-student"; // Return to the form if there are validation errors
		}
		studentService.addStudent(student);
		return "redirect:/students"; // Redirect to the students list
	}

	// Delete a student by ID
	@PostMapping("/delete/{id}")
	public String deleteStudent(@PathVariable int id) {
		studentService.deleteStudent(id);
		return "redirect:/students"; // Redirect to the students list after deletion
	}

	// Return all students as JSON
	@GetMapping("/json")
	public ResponseEntity<List<Student>> getAllStudentsJson() {
		return ResponseEntity.ok(studentService.getAllStudents());
	}
}
