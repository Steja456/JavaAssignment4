package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class StudentApplicationTests {

	@Test
	public void contextLoads() {
		// This test will pass if the Spring application context loads successfully.
	}
}
