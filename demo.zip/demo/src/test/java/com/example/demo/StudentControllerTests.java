package com.example.demo;

import com.example.demo.controller.StudentController;
import com.example.demo.service.StudentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(StudentController.class)
public class StudentControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private StudentService studentService;

	@Test
	public void testGetStudents() throws Exception {
		mockMvc.perform(get("/students"))
				.andExpect(status().isOk())
				.andExpect(view().name("students"));
	}

	@Test
	public void testPostInvalidStudent() throws Exception {
		mockMvc.perform(get("/students/save")
						.param("name", "")
						.param("email", "invalidemail")
						.param("age", "15"))
				.andExpect(status().isOk())
				.andExpect(view().name("new-student"));
	}
}
